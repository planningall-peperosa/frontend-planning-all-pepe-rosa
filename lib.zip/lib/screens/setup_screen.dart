import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';

// Import per i Dipendenti
import '../providers/dipendenti_provider.dart';
import '../models/cliente.dart';
import '../providers/clienti_provider.dart';

// Import per i Turni
import '../providers/turni_provider.dart';
import '../models/tipo_turno.dart';
import '../config/app_config.dart'; 


// Import per PIATTI + MENU
import '../providers/piatti_provider.dart';
import '../providers/menu_templates_provider.dart';
import '../models/piatto.dart';
import '../models/menu_template.dart';


import 'dart:convert';
import 'package:http/http.dart' as http;

import '../widgets/vibration_settings_card.dart';

import 'gestisci_contatto_screen.dart';

class SetupScreen extends StatefulWidget {

  @override
  _SetupScreenState createState() => _SetupScreenState();  
}



class AutorizzazioneApp {
  final String nome;
  int stato; // 0=disabled, 1=checked, 2=unchecked

  AutorizzazioneApp({required this.nome, required this.stato});

  factory AutorizzazioneApp.fromJson(Map<String, dynamic> json) {
    return AutorizzazioneApp(
      nome: json['nome'],
      stato: json['stato'],
    );
  }

  Map<String, dynamic> toJson() => {'nome': nome, 'stato': stato};
}



class _SetupScreenState extends State<SetupScreen> {
  List<AutorizzazioneApp> _autorizzazioniApp = [];
  bool _isLoadingAutorizzazioni = false;
  String? _erroreAutorizzazioni;

  // Generi/tipologie coerenti con i fogli Google
  static const List<String> _generi = ['antipasto','primo','secondo','contorno','piatto_unico'];
  static const List<String> _tipologie = ['carne','pesce','misto','neutro'];

  Widget _buildPiattiSection() {
    final theme = Theme.of(context);
    return Card(
      color: theme.colorScheme.primary,
      elevation: 2.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: Icon(Icons.restaurant_menu, color: theme.colorScheme.onPrimary),
        iconColor: theme.colorScheme.onPrimary,
        collapsedIconColor: theme.colorScheme.onPrimary,
        title: Text(
          'Gestione Piatti',
          style: TextStyle(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimary),
        ),
        // ⬇️ NUOVO: ogni volta che espandi, ricarica dal foglio
        onExpansionChanged: (expanded) {
          if (expanded) {
            context.read<PiattiProvider>().fetch();
          }
        },
        children: [
          Container(
            color: theme.colorScheme.background,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.add),
                      label: const Text('Nuovo Piatto'),
                      onPressed: () => _openPiattoDialog(),
                    ),
                  ),
                ),
                Consumer<PiattiProvider>(
                  builder: (ctx, prov, _) {
                    if (prov.isLoading && prov.piatti.isEmpty) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.all(12.0),
                          child: CircularProgressIndicator(),
                        ),
                      );
                    }
                    if (prov.error != null) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Text('Errore: ${prov.error}'),
                        ),
                      );
                    }
                    if (prov.piatti.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Text('Nessun piatto presente.'),
                      );
                    }
                    return ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: prov.piatti.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final p = prov.piatti[i];
                        return Dismissible(
                          key: ValueKey(p.idUnico),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            color: Colors.red,
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 16),
                            child: const Icon(Icons.delete, color: Colors.white),
                          ),
                          confirmDismiss: (direction) async {
                            final confermato = await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('Eliminare questo piatto?'),
                                content: Text(p.nome),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context, false),
                                    child: const Text('Annulla'),
                                  ),
                                  ElevatedButton(
                                    onPressed: () => Navigator.pop(context, true),
                                    child: const Text('Elimina'),
                                  ),
                                ],
                              ),
                            );

                            if (confermato != true) return false;

                            final ok = await context.read<PiattiProvider>().remove(p.idUnico);
                            if (!ok) {
                              final err = context.read<PiattiProvider>().error ?? 'Errore eliminazione piatto';
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                            }
                            return ok;
                          },
                          child: ListTile(
                            title: Text(p.nome),
                            subtitle: Text('${p.genere} • ${p.tipologia}'),
                            onTap: () => _openPiattoDialog(edit: p),
                          ),
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  Future<void> _openPiattoDialog({Piatto? edit}) async {
    final prov = context.read<PiattiProvider>();
    final formKey = GlobalKey<FormState>();
    String genere = edit?.genere ?? _generi.first;
    String tipologia = edit?.tipologia ?? _tipologie.first;
    final nomeCtrl  = TextEditingController(text: edit?.nome ?? '');
    final descrCtrl = TextEditingController(text: edit?.descrizione ?? '');
    final allergCtrl= TextEditingController(text: edit?.allergeni ?? '');
    final fotoCtrl  = TextEditingController(text: edit?.linkFoto ?? '');
    // Il controller del prezzo è stato RIMOSSO

    bool saving = false;
    bool deleting = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setStateDialog) {
          Future<void> _doSave() async {
            if (!formKey.currentState!.validate()) return;
            setStateDialog(() => saving = true);

            // --- MODIFICA CHIAVE: Payload aggiornato ---
            final payload = {
              'genere': genere,
              'nome': nomeCtrl.text.trim(),
              'descrizione': descrCtrl.text.trim(),
              'allergeni': allergCtrl.text.trim(),
              'link_foto_piatto': fotoCtrl.text.trim(), // <-- CORRETTO
              'tipologia': tipologia,
              // Il campo 'prezzo' è stato RIMOSSO
            };

            final ok = edit == null
                ? await prov.add(payload)
                : await prov.update(edit.idUnico, payload);

            if (!ctx.mounted) return;
            setStateDialog(() => saving = false);

            if (ok) {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(edit == null ? 'Piatto creato' : 'Piatto aggiornato')),
              );
            } else {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(prov.error ?? 'Operazione non riuscita')));
            }
          }

          Future<void> _doDelete() async {
            if (edit == null) return;
            final conferma = await showDialog<bool>(
              context: ctx,
              builder: (dctx) => AlertDialog(
                title: const Text('Eliminare il piatto?'),
                content: const Text('Questa operazione non può essere annullata.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(dctx, false), child: const Text('Annulla')),
                  ElevatedButton(onPressed: () => Navigator.pop(dctx, true), child: const Text('Elimina')),
                ],
              ),
            );
            if (conferma != true) return;

            setStateDialog(() => deleting = true);
            final ok = await prov.remove(edit.idUnico);
            if (!ctx.mounted) return;
            setStateDialog(() => deleting = false);

            if (ok) {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Piatto eliminato')));
            } else {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(prov.error ?? 'Eliminazione fallita')));
            }
          }

          return AbsorbPointer(
            absorbing: saving || deleting,
            child: AlertDialog(
              title: Row(
                children: [
                  Expanded(child: Text(edit == null ? 'Nuovo piatto' : 'Modifica piatto')),
                  if (edit != null)
                    IconButton(
                      tooltip: 'Elimina',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: deleting ? null : _doDelete,
                    ),
                ],
              ),
              contentPadding: const EdgeInsets.fromLTRB(16,12,16,4),
              content: SingleChildScrollView(
                child: Form(
                  key: formKey,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    DropdownButtonFormField<String>(
                      value: genere,
                      items: _generi.map((g)=>DropdownMenuItem(value:g, child: Text(g))).toList(),
                      onChanged: (v)=> genere = v!,
                      decoration: const InputDecoration(labelText: 'Genere'),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: nomeCtrl,
                      decoration: const InputDecoration(labelText: 'Nome piatto'),
                      validator: (v)=> (v==null || v.trim().isEmpty) ? 'Richiesto' : null,
                    ),
                    const SizedBox(height: 8),
                    // Il TextFormField del prezzo è stato RIMOSSO
                    DropdownButtonFormField<String>(
                      value: tipologia,
                      items: _tipologie.map((t)=>DropdownMenuItem(value:t, child: Text(t))).toList(),
                      onChanged: (v)=> tipologia = v!,
                      decoration: const InputDecoration(labelText: 'Tipologia'),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(controller: descrCtrl, decoration: const InputDecoration(labelText: 'Descrizione'), maxLines: 3),
                    const SizedBox(height: 8),
                    TextFormField(controller: allergCtrl, decoration: const InputDecoration(labelText: 'Allergeni')),
                    const SizedBox(height: 8),
                    TextFormField(controller: fotoCtrl, decoration: const InputDecoration(labelText: 'Link foto')),
                  ]),
                ),
              ),
              actions: [
                TextButton(onPressed: saving || deleting ? null : ()=>Navigator.pop(ctx), child: const Text('Annulla')),
                ElevatedButton(
                  onPressed: saving || deleting ? null : _doSave,
                  child: saving
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(edit == null ? 'Crea' : 'Salva'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }


  Widget _buildMenuTemplatesSection() {
    final theme = Theme.of(context);
    return Card(
      color: theme.colorScheme.primary,
      elevation: 2.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: Icon(Icons.menu_book, color: theme.colorScheme.onPrimary),
        iconColor: theme.colorScheme.onPrimary,
        collapsedIconColor: theme.colorScheme.onPrimary,
        title: Text(
          'Gestione Menu',
          style: TextStyle(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimary),
        ),
        // ⬇️ NUOVO: quando espandi, ricarica sia menu che piatti (per il picker)
        onExpansionChanged: (expanded) {
          if (expanded) {
            final menuProv = context.read<MenuTemplatesProvider>();
            final piattiProv = context.read<PiattiProvider>();
            menuProv.fetch();
            piattiProv.fetch();
          }
        },
        children: [
          Container(
            color: theme.colorScheme.background,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.add),
                      label: const Text('Nuovo Menu'),
                      onPressed: () => _openMenuDialog(),
                    ),
                  ),
                ),
                Consumer2<MenuTemplatesProvider, PiattiProvider>(
                  builder: (ctx, menuProv, piattiProv, _) {
                    if ((menuProv.isLoading && menuProv.templates.isEmpty) || piattiProv.isLoading) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.all(12.0),
                          child: CircularProgressIndicator(),
                        ),
                      );
                    }
                    if (menuProv.error != null) {
                      return Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Text('Errore: ${menuProv.error}'),
                      );
                    }
                    if (menuProv.templates.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Text('Nessun menu presente.'),
                      );
                    }
                    return ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: menuProv.templates.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final m = menuProv.templates[i];
                        return Dismissible(
                          key: ValueKey(m.idMenu),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            color: Colors.red,
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 16),
                            child: const Icon(Icons.delete, color: Colors.white),
                          ),
                          confirmDismiss: (direction) async {
                            final confermato = await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('Eliminare questo menu?'),
                                content: Text(m.nomeMenu),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annulla')),
                                  ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Elimina')),
                                ],
                              ),
                            );

                            if (confermato != true) return false;

                            final ok = await context.read<MenuTemplatesProvider>().remove(m.idMenu);
                            if (!ok) {
                              final err = context.read<MenuTemplatesProvider>().error ?? 'Errore eliminazione menu';
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                            }
                            return ok;
                          },
                          child: ListTile(
                            title: Text('${m.nomeMenu} • €${m.prezzo.toStringAsFixed(2)}'),
                            subtitle: Text(m.tipologia),
                            onTap: () => _openMenuDialog(edit: m),
                          ),
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  Future<void> _openMenuDialog({MenuTemplate? edit}) async {
    final menuProv = context.read<MenuTemplatesProvider>();
    final piattiProv = context.read<PiattiProvider>();

    final formKey = GlobalKey<FormState>();
    final nomeCtrl = TextEditingController(text: edit?.nomeMenu ?? '');
    final prezzoCtrl = TextEditingController(
        text: edit != null ? edit.prezzo.toStringAsFixed(2).replaceAll('.', ',') : '');
    final prezzoBambinoCtrl = TextEditingController(
        text: edit != null ? edit.prezzoBambino.toStringAsFixed(2).replaceAll('.', ',') : '0,00');

    String tipologia = edit?.tipologia ?? _tipologie.first;

    final Map<String, List<String>> composizione = {
      for (final g in _generi) g: List<String>.from(edit?.composizioneDefault[g] ?? []),
    };

    bool saving = false;
    bool deleting = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setStateDialog) {
          Future<void> _doSave() async {
            if (!formKey.currentState!.validate()) return;
            setStateDialog(() => saving = true);

            final prezzo = double.tryParse(prezzoCtrl.text.replaceAll(',', '.')) ?? 0.0;
            final prezzoBambino = double.tryParse(prezzoBambinoCtrl.text.replaceAll(',', '.')) ?? 0.0;

            final payload = {
              'nome_menu': nomeCtrl.text.trim(),
              'prezzo': prezzo,
              'prezzo_bambino': prezzoBambino,
              'tipologia': tipologia,
              'composizione_default': composizione,
            };

            final ok = edit == null
                ? await menuProv.add(payload)
                : await menuProv.update(edit.idMenu, payload);

            if (!ctx.mounted) return;
            setStateDialog(() => saving = false);

            if (ok) {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(edit == null ? 'Menu creato' : 'Menu aggiornato')),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(menuProv.error ?? 'Operazione non riuscita'),
                  backgroundColor: Colors.red));
            }
          }

          Future<void> _doDelete() async {
            // Assicurati di essere in modalità modifica
            if (edit == null) return;

            // Chiedi conferma all'utente
            final conferma = await showDialog<bool>(
              context: ctx, // Usa il contesto del dialog
              builder: (dctx) => AlertDialog(
                title: const Text('Eliminare il menu?'),
                content: Text('Stai per eliminare "${edit.nomeMenu}". L\'operazione non può essere annullata.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(dctx, false), child: const Text('Annulla')),
                  ElevatedButton(onPressed: () => Navigator.pop(dctx, true), child: const Text('Elimina')),
                ],
              ),
            );

            // Se l'utente non conferma, interrompi
            if (conferma != true) return;

            // Mostra lo spinner e chiama il provider
            setStateDialog(() => deleting = true);
            final ok = await menuProv.remove(edit.idMenu); // Usa l'ID corretto
            if (!ctx.mounted) return;
            setStateDialog(() => deleting = false);

            // Gestisci il risultato
            if (ok) {
              Navigator.pop(ctx); // Chiudi la finestra di modifica
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Menu eliminato')));
            } else {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(menuProv.error ?? 'Eliminazione fallita')));
            }
          }          
          // --- QUESTA È LA PARTE UI COMPLETA ---
          return AbsorbPointer(
            absorbing: saving || deleting,
            child: AlertDialog(
              title: Row(
                children: [
                  Expanded(child: Text(edit == null ? 'Nuovo menu' : 'Modifica menu')),
                  if (edit != null)
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: _doDelete,
                    ),
                ],
              ),
              contentPadding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              content: SingleChildScrollView(
                child: Form(
                  key: formKey,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextFormField(
                      controller: nomeCtrl,
                      decoration: const InputDecoration(labelText: 'Nome menu'),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Richiesto' : null,
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: prezzoCtrl,
                      decoration: const InputDecoration(labelText: 'Prezzo Adulto (€)'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (v) {
                        final d = double.tryParse((v ?? '').replaceAll(',', '.')) ?? 0;
                        return d > 0 ? null : 'Prezzo non valido';
                      },
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: prezzoBambinoCtrl,
                      decoration: const InputDecoration(labelText: 'Prezzo Bambino (€)'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: tipologia,
                      items: _tipologie.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                      onChanged: (v) => tipologia = v!,
                      decoration: const InputDecoration(labelText: 'Tipologia'),
                    ),
                    const SizedBox(height: 12),
                    ..._generi.map((g) {
                      final selectedIds = composizione[g]!;
                      final selectedPiatti = piattiProv.piatti.where((p) => selectedIds.contains(p.idUnico)).toList();
                      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Row(children: [
                          Expanded(child: Text(g.toUpperCase(), style: Theme.of(ctx).textTheme.titleMedium)),
                          TextButton.icon(
                            icon: const Icon(Icons.add),
                            label: const Text('Seleziona'),
                            onPressed: () async {
                              final picked = await _pickPiatti(genere: g, preselected: selectedIds);
                              if (picked != null) {
                                setStateDialog(() {
                                  composizione[g]!..clear()..addAll(picked);
                                });
                              }
                            },
                          ),
                        ]),
                        if (selectedPiatti.isEmpty)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text('Nessun $g selezionato',
                                style: TextStyle(color: Theme.of(ctx).hintColor, fontStyle: FontStyle.italic)),
                          )
                        else
                          Wrap(
                            spacing: 6,
                            runSpacing: -6,
                            children: selectedPiatti.map((p) => Chip(
                                    label: Text(p.nome),
                                    onDeleted: () => setStateDialog(() => composizione[g]!.remove(p.idUnico)),
                                  )).toList(),
                          ),
                        const Divider(),
                      ]);
                    }),
                  ]),
                ),
              ),
              actions: [
                TextButton(onPressed: saving || deleting ? null : () => Navigator.pop(ctx), child: const Text('Annulla')),
                ElevatedButton(
                  onPressed: saving || deleting ? null : _doSave,
                  child: saving
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(edit == null ? 'Crea' : 'Salva'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<List<String>?> _pickPiatti({
    required String genere,
    required List<String> preselected,
  }) async {
    final piatti = context.read<PiattiProvider>().piatti.where((p) => p.genere == genere).toList();
    final sel = preselected.toSet();

    return showModalBottomSheet<List<String>>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return DraggableScrollableSheet(
          expand: false, initialChildSize: 0.85,
          builder: (ctx, controller) => Column(
            children: [
              const SizedBox(height: 8),
              Container(width: 48, height: 5,
                decoration: BoxDecoration(color: Colors.grey.shade500, borderRadius: BorderRadius.circular(999))),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Seleziona $genere', style: Theme.of(ctx).textTheme.titleLarge),
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.separated(
                  controller: controller,
                  itemCount: piatti.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final p = piatti[i];
                    final selected = sel.contains(p.idUnico);
                    return ListTile(
                      title: Text(p.nome),
                      subtitle: Text(p.tipologia),
                      trailing: Checkbox(value: selected, onChanged: (_) {
                        selected ? sel.remove(p.idUnico) : sel.add(p.idUnico);
                        (ctx as Element).markNeedsBuild();
                      }),
                      onTap: () {
                        selected ? sel.remove(p.idUnico) : sel.add(p.idUnico);
                        (ctx as Element).markNeedsBuild();
                      },
                    );
                  },
                ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: Row(children: [
                    Expanded(child: OutlinedButton(onPressed: ()=>Navigator.pop(ctx, null), child: const Text('Annulla'))),
                    const SizedBox(width: 12),
                    Expanded(child: ElevatedButton(onPressed: ()=>Navigator.pop(ctx, sel.toList()), child: Text('Aggiungi (${sel.length})'))),
                  ]),
                ),
              ),
            ],
          ),
        );
      },
    );
  }




  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _refreshData();
    });
  }

  Future<void> _refreshData() async {
    await Future.wait([
      // Assicurati che questi provider legacy siano ancora necessari e funzionanti
      Provider.of<DipendentiProvider>(context, listen: false).fetchDipendenti(), // 🚨 NUOVO: CARICAMENTO DIPENDENTI DA FIRESTORE
      Provider.of<TurniProvider>(context, listen: false).fetchTipiTurno(),

      // Già refattorizzato
      Provider.of<ClientiProvider>(context, listen: false).fetchAllContacts(force: true),

      Provider.of<PiattiProvider>(context, listen: false).fetch(),
      Provider.of<MenuTemplatesProvider>(context, listen: false).fetch(),
    ]);
    await _fetchAutorizzazioniApp();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Setup'),
      ),
      body: RefreshIndicator(
        onRefresh: _refreshData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              _buildDipendentiSection(),
              const SizedBox(height: 16),
              _buildTurniSection(),

              _buildPiattiSection(),
              const SizedBox(height: 16),
              _buildMenuTemplatesSection(),
              const SizedBox(height: 16),

              const VibrationSettingsCard(),
              const SizedBox(height: 16),

              const SizedBox(height: 16),
              _buildAutorizzazioniAppSection(), 
            ],
          ),
        ),
      ),
    );
  }


// lib/screens/setup_screen.dart -> SOSTITUISCI QUESTA FUNZIONE

  Widget _buildAutorizzazioniAppSection() {
    final theme = Theme.of(context);
    
    return Card(
      color: theme.colorScheme.primary,
      elevation: 2.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: Icon(Icons.security, color: theme.colorScheme.onPrimary),
        iconColor: theme.colorScheme.onPrimary,
        collapsedIconColor: theme.colorScheme.onPrimary,
        title: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style.copyWith(fontSize: 16, color: theme.colorScheme.onPrimary),
            children: <TextSpan>[
              TextSpan(
                text: 'Autorizzazioni App ', 
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextSpan(
                text: '  - voci menu nascoste',
                style: TextStyle(fontWeight: FontWeight.normal, fontSize: 14),
              ),
            ],
          ),
        ),
        // MODIFICA: Il contenuto ora non ha più uno sfondo bianco separato.
        children: [
          if (_isLoadingAutorizzazioni)
            Center(child: Padding(
              padding: const EdgeInsets.all(12),
              child: CircularProgressIndicator(color: theme.colorScheme.onPrimary),
            )),
          if (_erroreAutorizzazioni != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(_erroreAutorizzazioni!, style: TextStyle(color: theme.colorScheme.onError)),
            ),
          if (!_isLoadingAutorizzazioni && _erroreAutorizzazioni == null)
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: _autorizzazioniApp.length,
              itemBuilder: (ctx, index) {
                final item = _autorizzazioniApp[index];
                final isDisabled = item.stato == 0;
                final isChecked = item.stato == 1;
                return ListTile(
                  leading: Checkbox(
                    value: isChecked,
                    activeColor: theme.colorScheme.onPrimary,
                    checkColor: theme.colorScheme.primary,
                     side: MaterialStateBorderSide.resolveWith(
                        (states) => BorderSide(width: 2.0, color: theme.colorScheme.onPrimary),
                      ),
                    onChanged: isDisabled
                        ? null
                        : (v) async {
                            final nuovoStato = isChecked ? 2 : 1;
                            setState(() {
                              _autorizzazioniApp[index].stato = nuovoStato;
                            });
                            await _aggiornaAutorizzazioneApp(item.nome, nuovoStato);
                          },
                  ),
                  title: Text(
                    item.nome,
                    style: isDisabled
                        ? TextStyle(
                            color: theme.colorScheme.onPrimary.withOpacity(0.5),
                            fontStyle: FontStyle.italic,
                          )
                        : TextStyle(color: theme.colorScheme.onPrimary),
                  ),
                  enabled: !isDisabled,
                );
              },
            ),
        ],
      ),
    );
  }   

  Widget _buildDipendentiSection() {
    final theme = Theme.of(context);
    return Card(
      color: theme.colorScheme.primary,
      elevation: 2.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: Icon(Icons.people, color: theme.colorScheme.onPrimary),
        iconColor: theme.colorScheme.onPrimary,
        collapsedIconColor: theme.colorScheme.onPrimary,
        title: Text('Gestione Dipendenti', style: TextStyle(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimary)),
        // ⬇️ NUOVO: Aggiungi fetch per caricare da Firestore
        onExpansionChanged: (expanded) {
          if (expanded) {
            context.read<DipendentiProvider>().fetchDipendenti();
          }
        },
        children: [
          Container(
            color: theme.colorScheme.background,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.add),
                      label: Text('Aggiungi'),
                      onPressed: () => _mostraDialogAggiungiDipendente(),
                    ),
                  ),
                ),
                Consumer<DipendentiProvider>(
                  builder: (ctx, provider, _) {
                    if (provider.isLoading && provider.dipendenti.isEmpty) {
                      return Center(child: CircularProgressIndicator());
                    }
                    if (provider.error != null) {
                      return Center(child: Text('Errore: ${provider.error}'));
                    }
                    if (provider.dipendenti.isEmpty) {
                      return Center(child: Text('Nessun dipendente trovato.'));
                    }
                    return ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: provider.dipendenti.length,
                      itemBuilder: (ctx, index) {
                        return DipendenteItem(
                          // 🚨 Modifica: DipendenteItem ora usa Cliente.idUnico è stato mappato su idCliente
                          key: ValueKey(provider.dipendenti[index].idCliente),
                          // 🚨 Modifica: Ora passa l'oggetto Cliente
                          dipendente: provider.dipendenti[index],
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }



  void _mostraDialogAggiungiDipendente() {
    final _formKey = GlobalKey<FormState>();
    final Map<String, String> _newData = {};
    final theme = Theme.of(context);
    final textStyle = TextStyle(color: theme.colorScheme.onSurface);
    
    // Per gestire il risultato asincrono del salvataggio
    bool _isSaving = false;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setStateDialog) {
          return AlertDialog(
            title: const Text('Aggiungi Dipendente'),
            content: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Nome Dipendente (mappato su ragione_sociale)
                    TextFormField(decoration: const InputDecoration(labelText: 'Nome Dipendente'), style: textStyle, validator: (v) => v!.isEmpty ? 'Campo obbligatorio' : null, onSaved: (v) => _newData['nome_dipendente'] = v!,),
                    // Ruolo
                    TextFormField(decoration: const InputDecoration(labelText: 'Ruolo'), style: textStyle, validator: (v) => v!.isEmpty ? 'Campo obbligatorio' : null, onSaved: (v) => _newData['ruolo'] = v!,),
                    // PIN (RIMOSSO)
                    // Email
                    TextFormField(decoration: const InputDecoration(labelText: 'Email'), style: textStyle, keyboardType: TextInputType.emailAddress, onSaved: (v) => _newData['email'] = v ?? '',),
                    // Telefono
                    TextFormField(decoration: const InputDecoration(labelText: 'Telefono'), style: textStyle, keyboardType: TextInputType.phone, onSaved: (v) => _newData['telefono'] = v ?? '',),
                    // Colore
                    TextFormField(decoration: const InputDecoration(labelText: 'Colore (es. #FF0000)'), style: textStyle, onSaved: (v) => _newData['colore'] = v ?? '',),
                    // CAMPI EXTRA RIMOSSI
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(onPressed: _isSaving ? null : () => Navigator.of(ctx).pop(), child: const Text('Annulla')),
              ElevatedButton(
                child: _isSaving
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Salva'),
                onPressed: _isSaving ? null : () async {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    setStateDialog(() => _isSaving = true);
                    
                    final success = await Provider.of<DipendentiProvider>(context, listen: false).addDipendente(_newData);
                    
                    if (ctx.mounted) {
                      setStateDialog(() => _isSaving = false);
                      if (success) {
                        Navigator.of(ctx).pop();
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dipendente aggiunto!'), backgroundColor: Colors.green));
                      } else {
                        final error = Provider.of<DipendentiProvider>(context, listen: false).error ?? 'Errore aggiunta dipendente.';
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: Colors.red));
                      }
                    }
                  }
                },
              ),
            ],
          );
        }
      ),
    );
  }
  
  void _confermaEliminazioneDipendente(String id) {
    final theme = Theme.of(context);
    final textStyle = TextStyle(color: theme.colorScheme.onPrimary);
    
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: theme.colorScheme.primary,
        title: Text('Sei sicuro?', style: textStyle),
        content: Text('Questa azione eliminerà il dipendente in modo permanente.', style: textStyle),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('Annulla', style: textStyle),
          ),
          TextButton(
            child: Text('Elimina', style: textStyle.copyWith(fontWeight: FontWeight.bold)),
            onPressed: () {
              Provider.of<DipendentiProvider>(context, listen: false).deleteDipendente(id);
              Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }


  Widget _buildTurniSection() {
    final theme = Theme.of(context);
    return Card(
      color: theme.colorScheme.primary,
      elevation: 2.0,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: Icon(Icons.access_time_filled, color: theme.colorScheme.onPrimary),
        iconColor: theme.colorScheme.onPrimary,
        collapsedIconColor: theme.colorScheme.onPrimary,
        title: Text('Gestione Turno', style: TextStyle(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimary)),
        // 🚨 MODIFICA: Forzare il fetch all'espansione da Firestore
        onExpansionChanged: (expanded) {
          if (expanded) {
            context.read<TurniProvider>().fetchTipiTurno();
          }
        },
        children: [
          Container(
            color: theme.colorScheme.background,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.add),
                      label: Text('Aggiungi Turno'),
                      onPressed: () => _mostraDialogAggiungiTurno(),
                    ),
                  ),
                ),
                Consumer<TurniProvider>(
                  builder: (ctx, provider, _) {
                    if (provider.isLoading && provider.tipiTurno.isEmpty) {
                      return Center(child: CircularProgressIndicator());
                    }
                    if (provider.error != null) {
                      return Center(child: Text('Errore: ${provider.error}'));
                    }
                    if (provider.tipiTurno.isEmpty) {
                      return Center(child: Text('Nessun tipo di turno trovato.'));
                    }
                    return ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: provider.tipiTurno.length,
                      itemBuilder: (ctx, index) {
                        return TurnoItem(
                          key: ValueKey(provider.tipiTurno[index].idTurno),
                          tipoTurno: provider.tipiTurno[index],
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }



  void _mostraDialogAggiungiTurno() {
    final _formKey = GlobalKey<FormState>();
    final Map<String, String> _newData = {};
    final theme = Theme.of(context);
    final textStyle = TextStyle(color: theme.colorScheme.onSurface);
    
    bool _isSaving = false;

    showDialog(
      context: context,
      barrierDismissible: false, // Per prevenire la chiusura durante il salvataggio
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setStateDialog) {
          return AlertDialog(
            title: const Text('Aggiungi Tipo Turno'),
            content: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(decoration: const InputDecoration(labelText: 'Nome Turno'), style: textStyle, validator: (v) => v!.isEmpty ? 'Obbligatorio' : null, onSaved: (v) => _newData['nome_turno'] = v!,),
                    const SizedBox(height: 16),
                    // Assumiamo che TimePickerFormField e SizeBox siano definiti altrove
                    TimePickerFormField(labelText: 'Orario Inizio', onSaved: (v) => _newData['orario_inizio'] = v!,),
                    const SizedBox(height: 16),
                    TimePickerFormField(labelText: 'Orario Fine', onSaved: (v) => _newData['orario_fine'] = v!,),
                  ]),
              )
            ),
            actions: [
              TextButton(onPressed: _isSaving ? null : () => Navigator.of(ctx).pop(), child: const Text('Annulla')),
              ElevatedButton(
                child: _isSaving 
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) 
                    : const Text('Salva'),
                // 🚨 Logica Asincrona Corretta
                onPressed: _isSaving ? null : () async {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    setStateDialog(() => _isSaving = true);
                    
                    final success = await Provider.of<TurniProvider>(context, listen: false).addTipoTurno(_newData);
                    
                    if (ctx.mounted) {
                      // 🚨 Importante: Ripristina _isSaving solo DOPO la chiamata await se fallisce
                      if (success) {
                        Navigator.of(ctx).pop();
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Turno aggiunto!'), backgroundColor: Colors.green));
                      } else {
                        setStateDialog(() => _isSaving = false); // 🚨 Ripristina lo stato qui in caso di errore
                        final error = Provider.of<TurniProvider>(context, listen: false).error ?? 'Errore aggiunta turno.';
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: Colors.red));
                      }
                    }
                  }
                },
              ),
            ],
          );
        }
      ),
    );
  }

  void _confermaEliminazioneTurno(String id) {
    final theme = Theme.of(context);
    final textStyleOnPrimary = TextStyle(color: theme.colorScheme.onPrimary);
    
    showDialog(
      context: context, 
      builder: (ctx) => AlertDialog(
        backgroundColor: theme.colorScheme.primary,
        title: Text('Confermi?', style: textStyleOnPrimary),
        content: Text('Questa azione eliminerà il tipo di turno.',style: textStyleOnPrimary),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: Text('Annulla', style: textStyleOnPrimary)),
          TextButton(
            child: Text('Elimina', style: TextStyle(color: theme.colorScheme.error, fontWeight: FontWeight.bold)),
            onPressed: () async { // 🚨 MODIFICA 1: Rendi la funzione asincrona
              // Chiudiamo il dialogo immediatamente
              Navigator.of(ctx).pop(); 

              // Eseguiamo l'operazione di eliminazione asincrona
              final success = await Provider.of<TurniProvider>(context, listen: false).deleteTipoTurno(id);
              
              // Gestiamo il feedback DOPO che l'operazione è terminata
              if (!success && mounted) {
                  final error = Provider.of<TurniProvider>(context, listen: false).error ?? 'Eliminazione fallita.';
                  // 🚨 MODIFICA 2: Usa context per lo ScaffoldMessenger
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: Colors.red));
              } else if (success && mounted) {
                   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Turno eliminato con successo!'), backgroundColor: Colors.green));
              }
            },
          ),
        ],
      )
    );
  }




  Future<void> _aggiornaAutorizzazioneApp(String nomeFunzione, int nuovoStato) async {
    final theme = Theme.of(context);
    final url = Uri.parse('${AppConfig.currentBaseUrl}/autorizzazioni-app');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'nome': nomeFunzione, 'nuovo_stato': nuovoStato}),
      );
      if (response.statusCode != 200) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Errore aggiornamento permesso (${response.statusCode})'),
          backgroundColor: theme.colorScheme.error,
        ));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Errore di rete: $e'),
        backgroundColor: theme.colorScheme.error,
      ));
    }
  }

  Future<void> _fetchAutorizzazioniApp() async {
    setState(() {
      _isLoadingAutorizzazioni = true;
      _erroreAutorizzazioni = null;
    });
    try {
      final url = Uri.parse('${AppConfig.currentBaseUrl}/autorizzazioni-app');
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final List<dynamic> lista = json.decode(response.body);
        setState(() {
          _autorizzazioniApp = lista.map((e) => AutorizzazioneApp.fromJson(e)).toList();
          _isLoadingAutorizzazioni = false;
        });
      } else {
        setState(() {
          _erroreAutorizzazioni = 'Errore di caricamento dati (${response.statusCode})';
          _isLoadingAutorizzazioni = false;
        });
      }
    } catch (e) {
      setState(() {
        _erroreAutorizzazioni = 'Errore: $e';
        _isLoadingAutorizzazioni = false;
      });
    }
  }

}

class DipendenteItem extends StatefulWidget {
  // 🚨 Modifica: Il tipo è ora Cliente
  final Cliente dipendente;
  DipendenteItem({Key? key, required this.dipendente}) : super(key: key);
  @override
  _DipendenteItemState createState() => _DipendenteItemState();
}

class _DipendenteItemState extends State<DipendenteItem> {

  final _formKey = GlobalKey<FormState>();

  bool _isEditing = false;
  bool _isExpanded = false;
  late TextEditingController _nomeController;
  late TextEditingController _ruoloController;
  late TextEditingController _emailController;
  late TextEditingController _telController;
  late TextEditingController _coloreController;

  @override
  void initState() {
    super.initState();
    _initControllers();
  }

  void _initControllers() {
    final dip = widget.dipendente;
    _nomeController = TextEditingController(text: dip.ragioneSociale);
    _ruoloController = TextEditingController(text: dip.ruolo);
    _emailController = TextEditingController(text: dip.mail);
    _telController = TextEditingController(text: dip.telefono01);
    _coloreController = TextEditingController(text: dip.colore);
  }
  
  @override
  void didUpdateWidget(DipendenteItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.dipendente != oldWidget.dipendente) {
      _initControllers();
    }
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _ruoloController.dispose();
    // PIN rimosso
    _emailController.dispose();
    _telController.dispose();
    _coloreController.dispose();
    // Campi extra rimossi
    super.dispose();
  }


  void _onSave() {
      // 🚨 CORREZIONE: Questo è il metodo corretto per aggiornare i DIPENDENTI.
      final theme = Theme.of(context);
      final Map<String, dynamic> data = {
        // Mappa da Cliente a payload (usa i nomi del payload del provider)
        'nome_dipendente': _nomeController.text, // Mappato su ragione_sociale nel provider
        'ruolo': _ruoloController.text,
        'email': _emailController.text, // Mappato su mail nel provider
        'telefono': _telController.text, // Mappato su telefono01 nel provider
        'colore': _coloreController.text,
      };

      // 🚨 Aggiornamento asincrono del Dipendente
      Provider.of<DipendentiProvider>(context, listen: false)
        .updateDipendente(widget.dipendente.idCliente, data)
        .then((success) {
          if (success && mounted) {
              setState(() { _isEditing = false; _isExpanded = false; });
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dipendente aggiornato!'), duration: Duration(seconds: 2),));
          } else if (mounted) {
              final error = Provider.of<DipendentiProvider>(context, listen: false).error ?? 'Errore durante l\'aggiornamento.';
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: theme.colorScheme.error,));
          }
      });
  }



  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      color: _isEditing ? theme.cardColor : theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: theme.colorScheme.primary.withOpacity(0.5), width: 1),
        borderRadius: BorderRadius.circular(4.0)
      ),
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: InkWell(
        onTap: () {
          if (!_isEditing) {
            setState(() {
              _isExpanded = !_isExpanded;
            });
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          // 🚨 Modifica: build view aggiornata (PIN e campi extra rimossi)
          child: _isEditing
              ? _buildEditingView()
              : (_isExpanded ? _buildExpandedView() : _buildReadOnlyView()),
        ),
      ),
    );
  }

  Widget _buildReadOnlyView() {
    final theme = Theme.of(context);
    final dip = widget.dipendente;
    // 🚨 Modifica: Rimuovi riferimento a pin e usa ragioneSociale/colore
    return ListTile(
      title: Text(dip.ragioneSociale ?? 'N/A', style: TextStyle(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimary)),
      subtitle: Text('Ruolo: ${dip.ruolo}\nTel: ${dip.telefono01}', style: TextStyle(color: theme.colorScheme.onPrimary.withOpacity(0.8))),
      leading: CircleAvatar(
        backgroundColor: dip.colore != null && dip.colore!.isNotEmpty 
            ? Color(int.parse(dip.colore!.replaceAll('#', '0xFF'))) 
            : theme.colorScheme.secondary,
        child: Text(dip.ragioneSociale?.substring(0,1).toUpperCase() ?? 'D', style: TextStyle(color: theme.colorScheme.onSecondary)),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: Icon(Icons.edit, color: theme.colorScheme.onPrimary),
            onPressed: () => setState(() => _isEditing = true),
          ),
          IconButton(
            icon: Icon(Icons.delete, color: theme.colorScheme.onPrimary),
            onPressed: () => (context.findAncestorStateOfType<_SetupScreenState>())?.
                _confermaEliminazioneDipendente(widget.dipendente.idCliente), // 🚨 Modifica: idUnico è ora idCliente
          ),
        ],
      ),
    );
  }

  Widget _buildExpandedView() {
    final theme = Theme.of(context);
    final dip = widget.dipendente;
    final textStyle = TextStyle(fontSize: 14, color: theme.colorScheme.onPrimary);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListTile(
          title: Text(dip.ragioneSociale ?? 'N/A', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: theme.colorScheme.onPrimary)),
          subtitle: Text('Ruolo: ${dip.ruolo}', style: textStyle),
          trailing: IconButton(
            icon: Icon(Icons.arrow_drop_up, size: 30, color: theme.colorScheme.onPrimary),
            onPressed: () {
              setState(() {
                _isExpanded = false;
              });
            },
          ),
        ),
        Divider(color: theme.colorScheme.onPrimary.withOpacity(0.2)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ID Contatto: ${dip.idCliente}', style: textStyle), // 🚨 Modifica: idUnico è ora idCliente
              Text('Email: ${dip.mail}', style: textStyle),
              Text('Telefono: ${dip.telefono01}', style: textStyle),
              Text('Colore: ${dip.colore}', style: textStyle),
              // 🚨 PIN e Campi Extra rimossi qui
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            IconButton(
              icon: Icon(Icons.edit, color: theme.colorScheme.onPrimary),
              onPressed: () => setState(() => _isEditing = true),
            ),
            IconButton(
              icon: Icon(Icons.delete, color: theme.colorScheme.error),
              onPressed: () => (context.findAncestorStateOfType<_SetupScreenState>())?.
                  _confermaEliminazioneDipendente(widget.dipendente.idCliente), // 🚨 Modifica: idUnico è ora idCliente
            ),
          ],
        ),
      ],
    );
  }


  Widget _buildEditingView() {
    final theme = Theme.of(context);
    final textStyle = TextStyle(color: theme.colorScheme.onSurface);
    return Form( // 🚨 CORREZIONE: Aggiungi il Form widget
      key: _formKey, // 🚨 CORREZIONE: Usa la form key
      child: Column(
        children: [
          TextFormField(controller: _nomeController, decoration: const InputDecoration(labelText: 'Nome'),style: textStyle,),
          TextFormField(controller: _ruoloController, decoration: const InputDecoration(labelText: 'Ruolo'),style: textStyle,),
          TextFormField(controller: _emailController, decoration: const InputDecoration(labelText: 'Email'), keyboardType: TextInputType.emailAddress,style: textStyle,),
          TextFormField(controller: _telController, decoration: const InputDecoration(labelText: 'Telefono'), keyboardType: TextInputType.phone,style: textStyle,),
          TextFormField(controller: _coloreController, decoration: const InputDecoration(labelText: 'Colore'),style: textStyle,),
          
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                child: const Text('Annulla'),
                onPressed: () {
                  _initControllers(); // Ri-inizializza i controller con i valori originali
                  setState(() { _isEditing = false; _isExpanded = true; });
                },
              ),
              ElevatedButton(
                child: const Text('Salva'),
                onPressed: () {
                  if (_formKey.currentState!.validate()) { // 🚨 Validazione
                    _formKey.currentState!.save(); // 🚨 Salvataggio
                    _onSave();
                  }
                },
              ),
            ],
          )
        ],
      ),
    );
  }
}


// lib/screens/setup_screen.dart -> classe TurnoItem e _TurnoItemState

class TurnoItem extends StatefulWidget {
  final TipoTurno tipoTurno; // 🚨 Corretto: TipoTurno è la prop corretta
  TurnoItem({Key? key, required this.tipoTurno}) : super(key: key);
  @override
  _TurnoItemState createState() => _TurnoItemState();
}

class _TurnoItemState extends State<TurnoItem> {
  // 🚨 CORREZIONE: Dichiarazione di tutte le variabili di stato mancanti
  final _formKey = GlobalKey<FormState>();
  
  String? _nomeTurno;
  String? _orarioInizio;
  String? _orarioFine;
  
  bool _isEditing = false;
  
  void _onSave() {
    final theme = Theme.of(context);
    // 🚨 CORREZIONE: Accesso corretto alle variabili di stato
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final data = {
        'nome_turno': _nomeTurno,
        'orario_inizio': _orarioInizio,
        'orario_fine': _orarioFine,
      };
      
      // 🚨 CORREZIONE: updateTipoTurno richiede idTurno
      Provider.of<TurniProvider>(context, listen: false)
        .updateTipoTurno(widget.tipoTurno.idTurno, data)
        .then((success) {
          if (success && mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Turno aggiornato!'), duration: Duration(seconds: 2)));
              setState(() => _isEditing = false);
          } else if (mounted) {
              final error = Provider.of<TurniProvider>(context, listen: false).error ?? 'Errore durante l\'aggiornamento.';
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: theme.colorScheme.error));
          }
        });
    }
  }

  @override
  Widget build(BuildContext class_context) {
    final theme = Theme.of(context);
    return Card(
      color: _isEditing ? theme.cardColor : theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: theme.colorScheme.primary.withOpacity(0.5), width: 1),
        borderRadius: BorderRadius.circular(4.0)
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: _isEditing ? _buildEditingView() : _buildReadOnlyView(),
      ),
    );
  }

  Widget _buildReadOnlyView() {
    final theme = Theme.of(context);
    return ListTile(
      title: Text(widget.tipoTurno.nomeTurno, style: TextStyle(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimary)),
      subtitle: Text('Orari: ${widget.tipoTurno.orarioInizio} - ${widget.tipoTurno.orarioFine}', style: TextStyle(color: theme.colorScheme.onPrimary.withOpacity(0.8))),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(icon: Icon(Icons.edit, color: theme.colorScheme.onPrimary), onPressed: () => setState(() => _isEditing = true)),
        IconButton(
          icon: Icon(Icons.delete, color: theme.colorScheme.onPrimary), // Colore unificato
          onPressed: () => (context.findAncestorStateOfType<_SetupScreenState>())
              ?. _confermaEliminazioneTurno(widget.tipoTurno.idTurno),
        ),
      ]),
    );
  }

  Widget _buildEditingView() {
    final theme = Theme.of(context);
    final textStyle = TextStyle(color: theme.colorScheme.onSurface);
    return Form(
      key: _formKey, // 🚨 CORREZIONE: formKey dichiarato sopra
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        TextFormField(
          initialValue: widget.tipoTurno.nomeTurno,
          decoration: const InputDecoration(labelText: 'Nome Turno'),
          style: textStyle,
          validator: (v) => v!.isEmpty ? 'Obbligatorio' : null,
          onSaved: (v) => _nomeTurno = v,
        ),
        const SizedBox(height: 16),
        TimePickerFormField(
          labelText: 'Orario Inizio',
          initialValue: widget.tipoTurno.orarioInizio,
          onSaved: (v) => _orarioInizio = v,
        ),
        const SizedBox(height: 16),
        TimePickerFormField(
          labelText: 'Orario Fine',
          initialValue: widget.tipoTurno.orarioFine,
          onSaved: (v) => _orarioFine = v,
        ),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.end, children: [
          TextButton(child: const Text('Annulla'), onPressed: () {
            setState(() => _isEditing = false);
          }),
          ElevatedButton(child: const Text('Salva'), onPressed: _onSave),
        ]),
      ]),
    );
  }
}


class TimePickerFormField extends FormField<String> {
  TimePickerFormField({
    Key? key,
    String labelText = 'Orario',
    String? initialValue,
    FormFieldSetter<String>? onSaved,
  }) : super(
          key: key,
          onSaved: onSaved,
          initialValue: initialValue ?? '00:00',
          validator: (value) {
            if (value == null || !RegExp(r'^[0-2][0-9]:[0-5][0-9]$').hasMatch(value)) {
              return 'Orario non valido';
            }
            return null;
          },
          builder: (FormFieldState<String> state) {
            return _TimePickerField(
              state: state,
              labelText: labelText,
            );
          },
        );
}

class _TimePickerField extends StatefulWidget {
  final FormFieldState<String> state;
  final String labelText;
  const _TimePickerField({required this.state, required this.labelText});
  @override
  _TimePickerFieldState createState() => _TimePickerFieldState();
}

class _TimePickerFieldState extends State<_TimePickerField> {
  late TextEditingController _hourController;
  late TextEditingController _minuteController;

  @override
  void initState() {
    super.initState();
    _hourController = TextEditingController();
    _minuteController = TextEditingController();
    _parseInitialValue();
  }
  
  @override
  void dispose() {
    _hourController.dispose();
    _minuteController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant _TimePickerField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.state.value != oldWidget.state.value) {
      _parseInitialValue();
    }
  }

  void _parseInitialValue() {
    try {
      final parts = widget.state.value!.split(':');
      _hourController.text = parts[0];
      _minuteController.text = parts[1];
    } catch (e) {
      _hourController.text = '00';
      _minuteController.text = '00';
    }
  }

  void _updateState() {
    final hours = _hourController.text.padLeft(2, '0');
    final minutes = _minuteController.text.padLeft(2, '0');
    final newValue = '$hours:$minutes';
    widget.state.didChange(newValue);
  }

  void _incrementHour() {
    int h = int.tryParse(_hourController.text) ?? 0;
    h = (h + 1) % 24;
    _hourController.text = h.toString().padLeft(2, '0');
    _updateState();
  }

  void _decrementHour() {
    int h = int.tryParse(_hourController.text) ?? 0;
    h = (h - 1 + 24) % 24;
    _hourController.text = h.toString().padLeft(2, '0');
    _updateState();
  }
  
  void _incrementMinute() {
    setState(() {
      int m = int.tryParse(_minuteController.text) ?? 0;
      int unit = m % 10;
      
      if (unit > 0 && unit < 5) {
        m = (m ~/ 10) * 10 + 5;
      } else if (unit > 5 && unit <= 9) {
        m = ((m ~/ 10) + 1) * 10;
      } else {
        m += 5;
      }

      if (m >= 60) m = 0;
      
      _minuteController.text = m.toString().padLeft(2, '0');
      _updateState();
    });
  }

  void _decrementMinute() {
    setState(() {
      int m = int.tryParse(_minuteController.text) ?? 0;
      int unit = m % 10;

      if (unit > 0 && unit < 5) {
        m = (m ~/ 10) * 10;
      } else if (unit > 5 && unit <= 9) {
        m = (m ~/ 10) * 10 + 5;
      } else {
        m -= 5;
      }

      if (m < 0) m = 55;

      _minuteController.text = m.toString().padLeft(2, '0');
      _updateState();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InputDecorator(
      decoration: InputDecoration(
        labelText: widget.labelText,
        errorText: widget.state.errorText,
        border: OutlineInputBorder(),
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildTimeColumn(
            controller: _hourController,
            onIncrement: _incrementHour,
            onDecrement: _decrementHour,
            maxValue: 23,
          ),
          Text(':', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: theme.colorScheme.onSurface)),
          _buildTimeColumn(
            controller: _minuteController,
            onIncrement: _incrementMinute,
            onDecrement: _decrementMinute,
            maxValue: 59,
          ),
        ],
      ),
    );
  }

  Widget _buildTimeColumn({
      required TextEditingController controller,
      required VoidCallback onIncrement,
      required VoidCallback onDecrement,
      required int maxValue
    }) {
    final theme = Theme.of(context);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          icon: Icon(Icons.arrow_drop_up, size: 30),
          padding: EdgeInsets.zero,
          constraints: BoxConstraints(),
          onPressed: onIncrement,
        ),
        SizedBox(
          width: 70,
          child: TextFormField(
            controller: controller,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: theme.colorScheme.onSurface),
            decoration: InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.zero, counterText: ''),
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(2),
              _TimeRangeTextInputFormatter(max: maxValue),
            ],
            onChanged: (value) => _updateState(),
          ),
        ),
        IconButton(
          icon: Icon(Icons.arrow_drop_down, size: 30),
          padding: EdgeInsets.zero,
          constraints: BoxConstraints(),
          onPressed: onDecrement,
        ),
      ],
    );
  }
}

class _TimeRangeTextInputFormatter extends TextInputFormatter {
  final int max;
  _TimeRangeTextInputFormatter({required this.max});

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    if (newValue.text.isEmpty) {
      return newValue;
    }
    final num = int.tryParse(newValue.text);
    if (num == null) return oldValue;
    if (num > max) return oldValue;
    return newValue;
  }
}